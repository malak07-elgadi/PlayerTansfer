package com.transfer.playertransfer.models;

public enum OfferStatus {
    ACCEPTED,
    REJECTED
}
