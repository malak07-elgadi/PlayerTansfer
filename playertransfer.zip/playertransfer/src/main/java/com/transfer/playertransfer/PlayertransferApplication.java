package com.transfer.playertransfer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PlayertransferApplication {

	public static void main(String[] args) {
		SpringApplication.run(PlayertransferApplication.class, args);
	}

}
