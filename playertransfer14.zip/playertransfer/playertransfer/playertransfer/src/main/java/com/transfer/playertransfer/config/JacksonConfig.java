// src/main/java/com/transfer/playertransfer/config/JacksonConfig.java
package com.transfer.playertransfer.config;

import com.fasterxml.jackson.datatype.hibernate6.Hibernate6Module;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class JacksonConfig {

    @Bean
    public Hibernate6Module hibernateModule() {
        Hibernate6Module m = new Hibernate6Module();
        // Pas de chargement forcé par Jackson (on utilise nos fetch join)
        m.disable(Hibernate6Module.Feature.FORCE_LAZY_LOADING);
        // Ne pas remplacer les objets LAZY non chargés par leur seul ID
        m.disable(Hibernate6Module.Feature.SERIALIZE_IDENTIFIER_FOR_LAZY_NOT_LOADED_OBJECTS);
        return m;
    }
}
