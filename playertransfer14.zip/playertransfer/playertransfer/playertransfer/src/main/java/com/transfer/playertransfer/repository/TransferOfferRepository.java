package com.transfer.playertransfer.repository;

import com.transfer.playertransfer.models.TransferOffer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;

public interface TransferOfferRepository extends JpaRepository<TransferOffer, Long> {

    // Charge le player ET son club en une seule requête (évite N+1) pour la liste
    @Query("""
           select o
           from TransferOffer o
           join fetch o.player p
           join fetch p.club c
           """)
    List<TransferOffer> findAllWithPlayerAndClub();

    // Charge le player ET son club pour un id donné
    @Query("""
           select o
           from TransferOffer o
           join fetch o.player p
           join fetch p.club c
           where o.id = :id
           """)
    Optional<TransferOffer> findByIdWithPlayerAndClub(Long id);
}
