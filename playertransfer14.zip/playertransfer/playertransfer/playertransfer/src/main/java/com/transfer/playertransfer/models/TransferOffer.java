package com.transfer.playertransfer.models;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDate;

@Entity
@Table(name = "transfer_offer")
@Getter
@Setter
@NoArgsConstructor
@JsonIgnoreProperties({"hibernateLazyInitializer","handler"})
public class TransferOffer {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "proposed_amount", precision = 19, scale = 2, nullable = false)
    private BigDecimal proposedAmount;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private OfferStatus status;

    // Si la colonne s'appelle "date" dans H2, on garde ce mapping
    @Column(name = "\"date\"", nullable = false)
    private LocalDate offerDate;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "player_id", nullable = false)
    // ⚠️ NE PAS ignorer "club" ici, sinon il ne s'affichera pas dans le JSON
    @JsonIgnoreProperties({"hibernateLazyInitializer","handler"})
    private Player player;
}
