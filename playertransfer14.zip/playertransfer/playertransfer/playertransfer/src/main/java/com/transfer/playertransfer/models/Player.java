package com.transfer.playertransfer.models;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;

@Entity
@Table(name = "players")
@Getter @Setter @NoArgsConstructor
@JsonIgnoreProperties({"hibernateLazyInitializer","handler"})
public class Player {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false) private String name;
    private int age;

    @Column(name = "transfer_value", precision = 19, scale = 2)
    private BigDecimal transferValue;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "club_id")
    // ignore proxys + n'embarque pas la liste players du club
    @JsonIgnoreProperties({"players","hibernateLazyInitializer","handler"})
    private Club club;
}
