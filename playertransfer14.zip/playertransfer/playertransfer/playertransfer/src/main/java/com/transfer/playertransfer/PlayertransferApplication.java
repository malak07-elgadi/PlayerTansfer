package com.transfer.playertransfer;

import com.transfer.playertransfer.models.Club;
import com.transfer.playertransfer.models.Player;
import com.transfer.playertransfer.repository.ClubRepository;
import com.transfer.playertransfer.repository.PlayerRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import java.math.BigDecimal;

@SpringBootApplication
public class PlayertransferApplication {

	public static void main(String[] args) {
		SpringApplication.run(PlayertransferApplication.class, args);
	}

	@Bean
	CommandLineRunner seed(PlayerRepository playerRepo, ClubRepository clubRepo) {
		return args -> {
			if (playerRepo.count() == 0) {
				// Clubs
				Club psg = new Club(); psg.setName("PSG"); psg = clubRepo.save(psg);
				Club fcb = new Club(); fcb.setName("FCB"); fcb = clubRepo.save(fcb);

				// Players (BigDecimal + setter correct)
				Player p1 = new Player();
				p1.setName("Lionel Messi");
				p1.setAge(37);
				p1.setTransferValue(new BigDecimal("1000000"));
				p1.setClub(psg);

				Player p2 = new Player();
				p2.setName("Kylian Mbappé");
				p2.setAge(26);
				p2.setTransferValue(new BigDecimal("1500000"));
				p2.setClub(psg);

				playerRepo.save(p1);
				playerRepo.save(p2);
			}
		};
	}
}
