package com.transfer.playertransfer.api;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import jakarta.servlet.http.HttpServletRequest;
import java.util.LinkedHashMap;
import java.util.Map;

@ControllerAdvice
public class ApiExceptionHandler {

    @ExceptionHandler(Exception.class)
    public ResponseEntity<Map<String, Object>> onAnyException(Exception ex, HttpServletRequest req) {
        // Log console pour stacktrace
        ex.printStackTrace();

        Map<String, Object> body = new LinkedHashMap<>();
        body.put("path", req.getRequestURI());
        body.put("error", ex.getClass().getName());
        body.put("message", ex.getMessage() == null ? "(no message)" : ex.getMessage());

        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(body);
    }
}
