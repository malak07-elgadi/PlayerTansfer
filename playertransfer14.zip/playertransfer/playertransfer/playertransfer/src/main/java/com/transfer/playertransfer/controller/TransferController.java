package com.transfer.playertransfer.controller;

import com.transfer.playertransfer.models.TransferOffer;
import com.transfer.playertransfer.service.TransferService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/transfers")
@RequiredArgsConstructor
public class TransferController {

    private final TransferService transferService;

    // GET /api/transfers
    @GetMapping
    public List<TransferOffer> getAllOffers() {
        return transferService.getAllOffers();
    }

    // GET /api/transfers/{id}
    @GetMapping("/{id}")
    public ResponseEntity<TransferOffer> getOfferById(@PathVariable Long id) {
        return transferService.getOfferById(id)
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    // POST /api/transfers
    @PostMapping
    public ResponseEntity<TransferOffer> createOffer(@RequestBody TransferOffer offer) {
        return ResponseEntity.ok(transferService.createOffer(offer));
    }
}
