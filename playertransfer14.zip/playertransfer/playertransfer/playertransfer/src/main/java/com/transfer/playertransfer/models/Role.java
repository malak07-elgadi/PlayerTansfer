package com.transfer.playertransfer.models;

public enum Role {
    PLAYER,
    CLUB,
    ADMIN
}
