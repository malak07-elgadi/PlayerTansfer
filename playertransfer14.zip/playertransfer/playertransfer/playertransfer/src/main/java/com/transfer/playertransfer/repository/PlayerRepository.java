package com.transfer.playertransfer.repository;

import com.transfer.playertransfer.models.Player;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PlayerRepository extends JpaRepository<Player, Long> {
}
