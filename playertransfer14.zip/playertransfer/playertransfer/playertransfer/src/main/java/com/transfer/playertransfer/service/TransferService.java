package com.transfer.playertransfer.service;

import com.transfer.playertransfer.models.Player;
import com.transfer.playertransfer.models.TransferOffer;
import com.transfer.playertransfer.repository.PlayerRepository;
import com.transfer.playertransfer.repository.TransferOfferRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class TransferService {

    private final TransferOfferRepository transferRepo;
    private final PlayerRepository playerRepo;

    // Liste : player + club chargés via fetch join
    public List<TransferOffer> getAllOffers() {
        return transferRepo.findAllWithPlayerAndClub();
    }

    // Détail : player + club chargés via fetch join
    public Optional<TransferOffer> getOfferById(Long id) {
        return transferRepo.findByIdWithPlayerAndClub(id);
    }

    @Transactional
    public TransferOffer createOffer(TransferOffer offer) {
        // Date par défaut si non fournie
        if (offer.getOfferDate() == null) {
            offer.setOfferDate(LocalDate.now());
        }

        // Validations simples
        if (offer.getProposedAmount() == null || offer.getProposedAmount().signum() <= 0) {
            throw new IllegalArgumentException("proposedAmount must be > 0");
        }
        if (offer.getStatus() == null) {
            throw new IllegalArgumentException("status is required");
        }

        // Si seul l'ID du joueur est fourni, on attache l'entité managée
        if (offer.getPlayer() != null && offer.getPlayer().getId() != null) {
            Long playerId = offer.getPlayer().getId();
            Player p = playerRepo.findById(playerId)
                    .orElseThrow(() -> new IllegalArgumentException("Player not found: " + playerId));
            offer.setPlayer(p);
        }

        return transferRepo.save(offer);
    }
}
